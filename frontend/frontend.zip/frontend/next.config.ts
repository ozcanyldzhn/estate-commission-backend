import type { NextConfig } from "next";

const NextConfig = {
  reactStrictMode: true,
  experimental: {
  typedRoutes: true
  }
  };
  
  
  module.exports = NextConfig;