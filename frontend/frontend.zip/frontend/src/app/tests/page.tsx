import { canTransition, calcCommission } from "@/lib/domain";

export const dynamic = "force-dynamic";

export default function TestsPage() {
  const tx = { amountMinor: 100_000, commissionRate: 0.03 } as const;

  const cases = [
    { name: "AGREEMENT -> EARNEST_MONEY allowed", pass: canTransition("AGREEMENT", "EARNEST_MONEY") },
    { name: "EARNEST_MONEY -> TITLE_DEED allowed", pass: canTransition("EARNEST_MONEY", "TITLE_DEED") },
    { name: "TITLE_DEED -> COMPLETED allowed", pass: canTransition("TITLE_DEED", "COMPLETED") },
    { name: "AGREEMENT -> COMPLETED not allowed", pass: !canTransition("AGREEMENT", "COMPLETED") },
    {
      name: "Commission equals 3% of amount",
      pass: calcCommission(tx).commissionMinor === Math.round(100_000 * 0.03)
    },
    {
      name: "Company+Agent split == commission",
      pass: (() => {
        const b = calcCommission(tx);
        return b.companyMinor + b.agentMinor === b.commissionMinor;
      })()
    }
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Runtime Tests</h1>
      <ul className="rounded-2xl border bg-white p-4">
        {cases.map((c) => (
          <li
            key={c.name}
            className="flex items-center justify-between py-1 text-sm"
          >
            <span>{c.name}</span>
            <span
              className={`rounded-full px-2 py-0.5 text-xs ${
                c.pass
                  ? "bg-green-100 text-green-700"
                  : "bg-red-100 text-red-700"
              }`}
            >
              {c.pass ? "PASS" : "FAIL"}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
