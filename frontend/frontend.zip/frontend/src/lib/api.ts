import axios from "axios";
import type { Transaction, Agent, TxStatus } from "@/lib/domain";

const base = process.env.NEXT_PUBLIC_BACKEND_URL || process.env.BACKEND_URL || '';
export const api = axios.create({
  baseURL: base ? `${base}/api` : '/api',
  headers: { 'Content-Type': 'application/json' }
});

// transactions
export async function listTransactions() {
  const { data } = await api.get(`/transactions`, { headers: { "Cache-Control": "no-store" } });
  return data;
}

export async function createTransaction(input: any) {
  const { data } = await api.post(`/transactions`, input);
  return data;
}

export async function advanceTransaction(id: string) {
  const { data } = await api.post(`/transactions/${id}/advance`);
  return data;
}

// optional helpers
export async function listAgents(): Promise<Agent[]> {
  const { data } = await api.get(`/agents`, { headers: { "Cache-Control": "no-store" } });
  return data;
}

export async function listUsers(params?: { page?: number; pageSize?: number }) {
  const { data } = await api.get(`/users`, { params });
  return data;
}

export async function createUser(body: any) {
  return (await api.post("/users", body)).data;
}

export default api;