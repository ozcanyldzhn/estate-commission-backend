export const CONFIG = {
    companyShareRate: 0.5,           // şirket payı (komisyondan %)
    defaultCommissionRateSale: 0.03, // satış default komisyon oranı
    defaultCommissionRateRent: 0.10, // kira default komisyon oranı
  } as const;